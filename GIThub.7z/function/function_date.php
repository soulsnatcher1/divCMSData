<?php            
/*******************************************************************************
 * 
 *   
 * Hier finden sich verschiedene Kalender oder Datumsfunktionen zum "Recycling"
 * Sie wirken lediglich als n�tzliche kleine Helferlein
 *  
 *   
*******************************************************************************/ 
$filename = "function_date.php";
$version = "1.0";
$description = "Verwendbare Datumsfunktionen"; 
       

 
//Funktion zur Ausgabe der ersten KW des �bergebenen Jahres
function firstkw($jahr) { 
  $erster = mktime(0,0,0,1,1,$jahr);
  $wtag = date('w',$erster);

   if ($wtag<= 4) {
       /**
        * Donnerstag oder kleiner: auf den Montag zur�ckrechnen.
        */
      $montag = mktime(0,0,0,1,1-($wtag-1),$jahr);
      } else if($wtag!=1) {
      /**
      * auf den Montag nach vorne rechnen.
      */
      $montag = mktime(0,0,0,1,1+(7-$wtag+1),$jahr);
      }
      else {
      $montag = $erster;
      }
   return $montag;
}  //Ende firstkw

//Funktion gibt den Montag einer �bergebenen KW zur�ck
function mondaykw($kw,$jahr) {
   $firstmonday = firstkw($jahr); 
   $mon_monat = date('m',$firstmonday);
   $mon_jahr = date('Y',$firstmonday);
   $mon_tage = date('d',$firstmonday);

   $tage =($kw-1)*7;

   $mondaykw = mktime(0,0,0,$mon_monat,$mon_tage+$tage,$mon_jahr);
   return $mondaykw;
}  //Ende mondaykw

//Function gibt den Wochentag eines �bergebenen Datums zur�ck. 
//Die variable $formatis steht f�r den R�ckgabeparameter der date() funktion
function givemeweekday($curQuarStart, $formatis=""){
	//M�gliche Parameter u.a.: 
	// - D = Wochentag, gek�rzt auf drei Buchstaben
	// - N = numerisch, 1 f�r Montag ISO-8601
	// - w = numerisch, 0 f�r Sonntag
	// - W = Kalenderwoche nach ISO-8601
if (trim($formatis) == ""){
		$formatis = "N";
	}else{
		$formatis = $formatis;
	}	
	//�bergebenes Datum zerlegen
	$month = substr($curQuarStart, 5, 2);
	$year = substr($curQuarStart, 0, 4);
	$day = substr($curQuarStart, 8, 2);
	 
	return date($formatis, mktime(0, 0, 0, $month, $day, $year));
}

//Funktion gibt das Datum (Startdatum +- einer �bergebenen Anzahl Tage zur�ck)
function daylessandmore($datestart,$subsign,$no_of,$date_form) {
//$datestart:  startdatum in englischem Format: Y-m-d
//$subsign: Plus oder Minuszeichen
//$no_of: Anzahl zu berechnender Tage 
//$date_form: bestimmt das Ausgabeformat des zu errechnenden Datums. So kann auch der
//Wochentag, die Kalenderwoche oder auch gleich ein anders formatiertes Datum zur�ck-
//gegeben werden. 
  $part_date = explode("-",$datestart);
  
  if ($subsign == '-'):
  
    $dateresult = date($date_form, mktime(0, 0, 0, $part_date['1'], $part_date['2'] - $no_of, $part_date['0']));
    
  elseif ($subsign == '+'):
  
    $dateresult =  date($date_form, mktime(0, 0, 0, $part_date['1'], $part_date['2'] + $no_of, intval($part_date['0'])));
    
  endif;
  
  return $dateresult;
}  //Ende daylessandmore





//Funktion gibt das Datum (Startdatum +- einer �bergebenen Anzahl Monate zur�ck)
function monthlessandmore($datestart,$subsign,$no_of,$date_form) {
//$datestart:  startdatum in englischem Format: Y-m-d
//$subsign: Plus oder Minuszeichen
//$no_of: Anzahl zu berechnender Monate 
//$date_form: bestimmt das Ausgabeformat des zu errechnenden Datums. So kann auch der
//Wochentag, die Kalenderwoche oder auch gleich ein anders formatiertes Datum zur�ck-
//gegeben werden. 
  $part_date = explode("-",$datestart);
  
  if ($subsign == '-'):
  
    $dateresult = date($date_form, mktime(0, 0, 0, $part_date['1'] - $no_of, $part_date['2'], $part_date['0']));
    
  elseif ($subsign == '+'):
  
    $dateresult =  date($date_form, mktime(0, 0, 0, $part_date['1'] + $no_of, $part_date['2'], $part_date['0']));
    
  endif;
  
  return $dateresult;
}  //Ende monthlessandmore



//einfacher Tagesdifferenzz�hler
function count_days ($start, $end){
	$dayscount = floor((strtotime($end)-strtotime($start))/86400); 
	return $dayscount;
}



//Array erstellen mit den Feiertagen in RheinlandPfalz des �bergebenen Jahres
function feiertage ($act_year){
#return($act_year);	exit;
	$feiertage = array (
	"0101".$act_year => 'Neujahr',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'-',2,'dm').$act_year => 'Karfreitag',
	date("dm", easter_date($act_year)).$act_year => 'Ostersonntag',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'+',1,'dm').$act_year => 'Ostermontag',
	"0105".$act_year => 'Tag der Arbeit',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'+',39,'dm').$act_year => 'Christi Himmelfahrt',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'+',49,'dm').$act_year => 'Pfingstsonntag',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'+',50,'dm').$act_year => 'Pfingstmontag',
	daylessandmore(date("Y-m-d", easter_date($act_year)),'+',60,'dm').$act_year => 'Fronleichnam',
	"0310".$act_year => 'Tag der Deutschen Einheit',
	"0111".$act_year => 'Allerheiligen',
	"2412".$act_year => 'Heiligabend',
	"2512".$act_year => 'Erster Weihnachtstag',
	"2612".$act_year => 'Zweiter Weihnachtstag',
	"3112".$act_year => 'Silvester',
	
	);
	
return($feiertage);	
}


//Funktion zur Errechnung der Anzahl von Tagen zwischen zwei Datumsangaben.
//Das Format der Datums�bergabe, wird durch die dritte und vierte Variable entschieden: seDay($timeA,$timeB,"dmY","."); = Deutsches Format 
function seDay($begin,$end,$format,$sep){

$pos1 = strpos($format, 'd');
$pos2 = strpos($format, 'm');
$pos3 = strpos($format, 'Y');

$begin = explode($sep,$begin);
$end = explode($sep,$end);

$first = GregorianToJD($end[$pos2],$end[$pos1],$end[$pos3]);
$second = GregorianToJD($begin[$pos2],$begin[$pos1],$begin[$pos3]);

if($first > $second)
   return $first - $second;
else
   return $second - $first;

} 
################################################
//SQl Feld mit Datum und Zeit nach der gew�hlten Sprache ausgeben
function format_time_date($value){

  if ($_SESSION['Language'] == 'DE'){

$date = substr($value,0,10);
$time = substr($value,-9,-3);

   list($year, $month, $day) = explode("-", $date);

   return sprintf("%02d.%02d.%04d; ".$time, $day, $month, $year  );//Ausgabe des deutschen Formates

  }//Ende if DE
	else{
	return $value; //Nach ISO 8601
	}
}


?>
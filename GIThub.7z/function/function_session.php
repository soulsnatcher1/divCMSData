<?
/************************************************************************
 * 
 * Diese Datei bietet alle Funktionen an, die im Zusammenhang mit dem Login stehen
 * 
 * 
 * Erst die Definition von verschiedenen Links und Formularen
************************************************************************/

          
/************************************************************************
 *  Abarbeiten des Loginvorgangs
************************************************************************/
function check_user($name, $pass)
{
    $sql="SELECT UserId 
    FROM ".DBNAME.".".MEMBER_TABLE."
    WHERE UserName='".$name."' AND UserPasswd=MD5('".$pass."')
    AND UserActive = '1'
    LIMIT 1"; 
    $result= my_query($sql);
    if ( mysqli_num_rows($result)==1)
    {
        $user=mysqli_fetch_assoc($result);
        return $user['UserId'];  
    }
    else
        return false;
}

function login($userid)
{
	$tempsessionid = session_id();
	$_SESSION['user_session'] = $tempsessionid;
	
    $sql="UPDATE ".DBNAME.".".MEMBER_TABLE."
    SET UserSession='".$tempsessionid."',
    UserLogin = NOW()
    WHERE UserId=".$userid; 
     my_query($sql);    
    
}

function logged_in()
{
    $sql="SELECT UserId
    FROM ".DBNAME.".".MEMBER_TABLE."
    WHERE UserSession='".session_id()."'
    LIMIT 1"; 
    $result= my_query($sql);
      return ( mysqli_num_rows($result)==1);
      #return $sql;
}

function logout()
{
    $sql="UPDATE ".DBNAME.".".MEMBER_TABLE."
    SET UserSession=NULL,
    UserLogout = NOW()
    WHERE UserSession='".session_id()."'";
     my_query($sql);
session_destroy();
}


?>
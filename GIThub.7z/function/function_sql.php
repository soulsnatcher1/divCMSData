<?php

/***************************************************************************
*
* JL-FraWo, Autor und alle Rechte: Andreas K�hnapfel
* http://kuehnapfel.de
* root@kuehnapfel.de
* Datei: function_sql.php
*
***************************************************************************/

// Stellt die SQL Anbindung her 
$conn=mysqli_connect(DBHOST, DBUSER,DBPASS,DBNAME);

if (!$conn) {
	echo "Fehler: konnte nicht mit MySQL verbinden." . PHP_EOL; 
	exit;
}

$_SESSION['conn'] = $conn;

function my_query($query)
{
#
  $_SESSION["SQL_Counter"]= ($_SESSION["SQL_Counter"]+1);

 #if(!($returnval = mysql_query($query)))
 if(!($returnval = mysqli_query($_SESSION['conn'], $query)))
 {
  die(mysql_errno() . ") query: <pre>".$query."<pre> fehlgeschlagen " . mysql_error());

 }
 


 return $returnval;

}


?>
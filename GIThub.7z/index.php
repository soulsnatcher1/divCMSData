<?php
session_start();  // Neue Session  

/***************************************************************************
*
* JL-EWMS, Autor und alle Rechte: Andreas Kühnapfel
* http://kuehnapfel.de
* root@kuehnapfel.de
* Datei: index.php 
*
***************************************************************************/ 
//Zeitzone setzen
date_default_timezone_set('Europe/Berlin');

// Anfang der Ladezeit berechnung
$starttime = explode(" ", microtime());
$_SESSION["starttime"] = $starttime[0]+$starttime[1];
 
// Session variable für den SQL Zähler
$_SESSION["SQL_Counter"] = '0';
 
/***************************************************************************
* Error Reporting
***************************************************************************/
// errorreporting einschalten: 
error_reporting ( E_ERROR | E_WARNING | E_PARSE );
ini_set ( 'display_errors' , true );  
 
/***************************************************************************
* Error Reporting ENDE 
***************************************************************************/

// Config einbinden
include ('cf-data/holo-conf.php'); //Einstellungen laden
 
// Funktionsdateien einbinden
// DB Anbindung und SQL spezifische Funktionen einbinden
include(FUNC_PATH."function_sql.php"); 
 
// Frameworkfunktionen   
include(FUNC_PATH."function_framework.php");

// Sessionhandling für login/logout etc.
include(FUNC_PATH."function_session.php");


/***************************************************************************
* Sammeln der erforderlichen Informationen
***************************************************************************/
 
  //Funktion um die Grundeinstellungen zu ermitteln  
   setDomData();  
   

?>
 
 
<?php 
/**
 * 
 * sharedReadFileProperties.php Ver 1.0
 * 
 * Liest die Eigenschaften einer Datei aus.
 */

function sharedReadFileProperties($file){
	$filearray['fileName'] = $file;
	$filearray['fileLastUpdate'] = $changedate=date ("Y-m-d H:i:s.", filemtime($par_dir."/".$file)); 
	$filearray['filePermission'] = substr(sprintf('%o', fileperms($file)), -4);
	return $filearray;
}
?>
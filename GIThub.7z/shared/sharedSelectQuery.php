<?php 
/**
 * 
 * sharedSelectQuery.php Vers. 1.0
 * 
 * Funktion setzt einen Query nach �bergebenen Werten ein, 
 * 
 */


function sharedSelectQuery($usedDataFilePath, $usedDataFile, $resultLimiter = "", $orderDirection = "", $orderPreByKey = ""){
 

	/**
	 *
	 *
	 * Vorbelegen 
	 */		
	$orderByKey = $orderPreByKey;
	$orderDirectionIs = '';
	$resultLimiterIs = '';
	
	//Beschreibung einbinden
	include_once($usedDataFilePath.$usedDataFile.".php");
/**
 * 
 * Zuerst pr�fen ob ein spezieller Query gewuenscht ist
 */	
	if (isset($buildedSpecialQuery)){
		
		return $buildedSpecialQuery;
		continue;
/**
 * 
 * Pr�fen ob ein Join eingerichtet werden soll.-
 */		
	}elseif(!empty($joinOverThis)){

		//Array in Schleife auslesen
		foreach ($usedFieldArray as $subkey => $tableProperties) {
			if ((trim($orderPreByKey) == '') AND (trim($usedFieldArray[$subkey]['fieldKey']) == 'PRI') ){
					
				$orderByKey = $usedFieldArray[$subkey]['fieldName'];
			}
			//  			echo $usedFieldArray[$subkey]['fieldName']." - ".$usedFieldArray[$subkey]['fieldType']." - ".$usedFieldArray[$subkey]['fieldKey']." <br>";
				
		}

		/**
		 * Order By und Limit entscheiden
		 *
		 */
			
		if (trim($orderDirection) != ''){
			$orderDirectionIs = $orderDirection;
		}
			
		if (trim($resultLimiter) != ''){
			$resultLimiterIs = 'LIMIT '.$resultLimiter;
		}
			
		if (trim($orderByKey) != ''){
		
			$orderByKeyIs = 'ORDER BY '.$orderByKey;
		}		
		
		
		$joinOverTags = ''; 
		foreach ($joinOverThis as $joinPart){
			$joinOverTags .= $joinPart."\n";
			 $query = "
				SELECT * 
			 		FROM ".$usedtableName." 
			 		".$joinOverTags."
					".$orderByKeyIs."  
					".$orderDirectionIs."	 
					".$resultLimiterIs."	
				;";
		}
		return $query;
	}else{
		
 
				
		//Array in Schleife auslesen
		foreach ($usedFieldArray as $subkey => $tableProperties) {
			if ((trim($orderPreByKey) == '') AND (trim($usedFieldArray[$subkey]['fieldKey']) == 'PRI') ){
					
				$orderByKey = $usedFieldArray[$subkey]['fieldName'];
			}
			//  			echo $usedFieldArray[$subkey]['fieldName']." - ".$usedFieldArray[$subkey]['fieldType']." - ".$usedFieldArray[$subkey]['fieldKey']." <br>";
				
		}
			
		/**
		 * Order By und Limit entscheiden
		 *  
		 */	
			
			if (trim($orderDirection) != ''){
				$orderDirectionIs = $orderDirection;
			}
			
			if (trim($resultLimiter) != ''){
				$resultLimiterIs = 'LIMIT '.$resultLimiter;
			}
			
			if (trim($orderByKey) != ''){
				
				$orderByKeyIs = 'ORDER BY '.$orderByKey;
			}
		 
		
			/**
			 * 
			 * Query erstellen
			 */
			 $query = "
				SELECT * 
			 		FROM ".$usedtableName." 
					".$orderByKeyIs."  
					".$orderDirectionIs."	 
					".$resultLimiterIs."	
				;";
		
		 
			/**
			 * Ausgeben
			 */
			return $query;
	}//Ende pr�fen von bestimmtem Query
}
?>
<?php 
/**
 * 
 * sharedSelectQuery.php Vers. 1.0
 *  
 */


function sharedShowTables($dataBase, $showAttributes, $notToShowPrefix = ""){
 

	$sql = "SHOW TABLES FROM ".$dataBase.";";

	$result = my_query($sql);
	$i = '0';
	//die gefundenen Tabellen werden im einzelnen untersucht
	while ($row = mysqli_fetch_array($result,MYSQL_NUM)) { //While 1, suche nach Tabellen

	if ( (isset($notToShowPrefix)) AND (trim($notToShowPrefix) == '')){
		$i++;
		$resultdata[$i] = $row['0'];
	}
// 		//Dazu wird erst mal nachgesehen, welche Felder da vorhanden sind
// 		$fieldstr = ' (';
	if ( (isset($showAttributes)) AND ($showAttributes == 'YES')){
  		$sqlsub = "SHOW COLUMNS FROM ".$row['0'].";";
// 		$resultsub = my_query($sqlsub);
	
	
			
// 		while ($rowsub = mysqli_fetch_array($resultsub,MYSQL_NUM)) {
				
// 			$fieldstr .= $rowsub['0']." LIKE (REPLACE(REPLACE('*".$seekterm."*','*','%'),'?','_')) OR " ;
	
// 		}
	}
	/**
	 * Ausgabe
	 */
	}
			return $resultdata;
	 
}
?>